exports.config = {
  development: {
    username: "root",
    password: "prs@353737",
    database: "lego_sell_db",
    host: "localhost",
    dialect: "mysql",
  },
};
